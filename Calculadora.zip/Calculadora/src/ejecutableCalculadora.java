
public class ejecutableCalculadora {

	public static void main(String[] args) {
		
		
		System.out.println(Calculadora.calculaFactorial(5));
		
		System.out.println(Calculadora.toStringArr(Calculadora.calculaFibonacci(8)));

		System.out.println(Calculadora.esDivisiblePor11(121));
		
	}

}
